package com.FoodDeliveryApp.restrauntservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestrauntServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
